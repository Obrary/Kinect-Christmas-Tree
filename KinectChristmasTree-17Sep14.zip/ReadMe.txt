Product: Kinect Christmas Tree, September 2014

Designer: Jens Dyvik, http://www.dyvikdesign.com/

Support:  support@obrary.com

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
Kinect Christmas Tree is designed to be printed on a laser cutter.  It can be made from plywood or acrylic.